% A lid-driven cavity flow problem using Streamfunction-Vorticity formulation
% Change the boundary conditions


clear;

% specify Reynolds number
Re=10;

% set up the grids
Nx=20;Ny=Nx;   % no. of intervals
Lx=1;Ly=Lx;

x=linspace(0,Lx,Nx+1);x=x(:);dx=x(2)-x(1);
y=linspace(0,Ly,Ny+1);y=y(:);
dl=dx;      % Here dx=dy, so we use dl to represent them

[x2,y2]=meshgrid(x,y);    % generate a 2D mesh

% specify the value of dt
dt=0.006;   % dt_max = 0.00625

NMax=100;   % maximum of time steps. Total time = NMax*dt

% assemble A matrix to solve the Poisson equation Au=b
[A]=assembleA(Nx,Ny,dl);

% initial condition for the vorticity
vort = zeros(Nx-1,Ny-1);
t=0;

energyarray=[];

% new boundary conditions
% U_north_new=sin(2*pi*x(2:end-1)/Lx);
U_north_new=sin(pi*x(2:end-1)/Lx).^2; % new bc
% U_north_new=ones(Nx-1,1); % old bc

% figure('units','normalized','outerposition',[0 0 1 1])

% time evoluion
for i=1:NMax

stmfunc = solve_Poisson(vort,A,Nx,Ny);            % solving the Poisson equation
                                                  % for streamfunction

vort = advance_vort(stmfunc,vort,Nx,Ny,dl,dt,Re,U_north_new); % advance the vorticity transport 
                                                  % equation

disp(['Finish timestep' num2str(i)])

t=t+dt;

% for plotting
figure(1)
subplot(1,2,1)
[u,v]=get_uv(stmfunc,Nx,Ny,dl,U_north_new);
quiver(x2,y2,u',v')
axis equal
xlim([0 1]);ylim([0 1.1]);
title(['At time step = ' num2str(i)])
set(gca,'FontSize',40)
% pause(0.0001)
drawnow

energyarray = [energyarray sqrt(u(end-1,end-1)^2+v(end-1,end-1)^2)];

subplot(1,2,2)
plot(dt:dt:dt*i,energyarray,'-*b')
title(['The kinetic energy at the grid point (' num2str(x(end-1)) ',' num2str(y(end-1)) ')'])
set(gca,'FontSize',20)

end

% post-processing
plot_results(stmfunc,vort,Nx,Ny,dl,x,y,x2,y2,U_north_new)
