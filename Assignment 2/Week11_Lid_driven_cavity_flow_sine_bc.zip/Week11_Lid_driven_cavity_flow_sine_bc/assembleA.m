function [A]=assembleA(Nx,Ny,dl)

h2=dl*dl;

A=zeros((Nx-1)*(Ny-1),(Nx-1)*(Ny-1));

% interior
for j=2:Ny-2
    for i=2:Nx-2
        po=i+(j-1)*(Nx-1);
        A(po,po)= -4/h2; 
        A(po,po+1)=1/h2; 
        A(po,po-1)=1/h2;
        A(po,po-(Nx-1))=1/h2;
        A(po,po+(Nx-1))=1/h2;
    end
end

% South
j=1;
for i=2:Nx-2
        po=i+(j-1)*(Nx-1);
        A(po,po)= -4/h2; 
        A(po,po+1)=1/h2; 
        A(po,po-1)=1/h2;
%         A(po,po-(Nx-1))=1/h2;
        A(po,po+(Nx-1))=1/h2;
end

% North
j=Ny-1;
for i=2:Nx-2
        po=i+(j-1)*(Nx-1);
        A(po,po)= -4/h2; 
        A(po,po+1)=1/h2; 
        A(po,po-1)=1/h2;
        A(po,po-(Nx-1))=1/h2;
%         A(po,po+(Nx-1))=1/h2;
end

% West
i=1;
for j=2:Ny-2
        po=i+(j-1)*(Nx-1);
        A(po,po)= -4/h2; 
        A(po,po+1)=1/h2; 
%         A(po,po-1)=1/h2;
        A(po,po-(Nx-1))=1/h2;
        A(po,po+(Nx-1))=1/h2;
end

% East
i=Nx-1;
for j=2:Ny-2
        po=i+(j-1)*(Nx-1);
        A(po,po)= -4/h2; 
%         A(po,po+1)=1/h2; 
        A(po,po-1)=1/h2;
        A(po,po-(Nx-1))=1/h2;
        A(po,po+(Nx-1))=1/h2;
end

% South-west
i=1;j=1;
        po=i+(j-1)*(Nx-1);
        A(po,po)= -4/h2; 
        A(po,po+1)=1/h2; 
%         A(po,po-1)=1/h2;
%         A(po,po-(Nx-1))=1/h2;
        A(po,po+(Nx-1))=1/h2;

% South-east          
i=Nx-1;j=1;
        po=i+(j-1)*(Nx-1);
        A(po,po)= -4/h2; 
%         A(po,po+1)=1/h2; 
        A(po,po-1)=1/h2;
%         A(po,po-(Nx-1))=1/h2;
        A(po,po+(Nx-1))=1/h2;

% North-east         
i=Nx-1;j=Ny-1;
        po=i+(j-1)*(Nx-1);
        A(po,po)= -4/h2; 
%         A(po,po+1)=1/h2; 
        A(po,po-1)=1/h2;
        A(po,po-(Nx-1))=1/h2;
%         A(po,po+(Nx-1))=1/h2;

% North-west          
i=1;j=Ny-1;
        po=i+(j-1)*(Nx-1);
        A(po,po)= -4/h2; 
        A(po,po+1)=1/h2; 
%         A(po,po-1)=1/h2;
        A(po,po-(Nx-1))=1/h2;
%         A(po,po+(Nx-1))=1/h2;

end