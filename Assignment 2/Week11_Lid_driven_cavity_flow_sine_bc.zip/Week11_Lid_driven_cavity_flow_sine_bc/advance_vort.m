function [vortnew] = advance_vort(stmfunc,vort,Nx,Ny,dl,dt,Re,U_north_new)
%SOLVE_ Summary of this function goes here
%   Detailed explanation goes here

RHS = assembleRHS(Nx,Ny,stmfunc,vort,Re,dl,U_north_new);

vortnew = vort + dt*RHS;
                                
end









