function [RHS] = assembleRHS(Nx,Ny,stmfunc,vort,Re,dl,U_north_new)
%ASSEMBLERHS Summary of this function goes here
%   Detailed explanation goes here

% the boundary conditions at the boundaries
U_south = zeros(Nx-1,1);
U_north = U_north_new; % new boundary conditions
U_west  = zeros(Ny-1,1);
U_east  = zeros(Ny-1,1);

nu=1/Re;
dl2=dl*dl;

RHS=zeros(Nx-1,Ny-1);

% interior
for j=2:Ny-2
    for i=2:Nx-2
        fac1 = -(stmfunc(i,j+1) - stmfunc(i,j-1))/2/dl;
        fac2 =  (stmfunc(i+1,j) - stmfunc(i-1,j))/2/dl;

        RHS(i,j) =  fac1*( vort(i+1,j)-vort(i-1,j) )/2/dl + ...
                    fac2*( vort(i,j+1)-vort(i,j-1) )/2/dl + ...
                    nu*( ( vort(i+1,j)-2*vort(i,j)+vort(i-1,j) )/dl2 + ... 
                         ( vort(i,j+1)-2*vort(i,j)+vort(i,j-1) )/dl2 );                     
    end
end

% south
j=1;

for i=2:Nx-2
    vortsouthbc = ( 0 - stmfunc(i,j) + U_south(i)*dl)/(0.5*dl*dl);
        
    fac1 = -(stmfunc(i,j+1) - 0             )/2/dl;
    fac2 =  (stmfunc(i+1,j) - stmfunc(i-1,j))/2/dl;

    RHS(i,j) =  fac1*( vort(i+1,j)-vort(i-1,j) )/2/dl + ...
                fac2*( vort(i,j+1)-vortsouthbc )/2/dl + ...
                nu*( ( vort(i+1,j)-2*vort(i,j)+vort(i-1,j) )/dl2 + ... 
                     ( vort(i,j+1)-2*vort(i,j)+vortsouthbc )/dl2 ); 
end

% North
j=Ny-1;
for i=2:Nx-2
    vortnorthbc = ( 0 - stmfunc(i,j) - U_north(i)*dl)/(0.5*dl*dl);
        
    fac1 = -(0              - stmfunc(i,j-1))/2/dl;
    fac2 =  (stmfunc(i+1,j) - stmfunc(i-1,j))/2/dl;

    RHS(i,j) =  fac1*( vort(i+1,j)-vort(i-1,j) )/2/dl + ...
                fac2*( vortnorthbc-vort(i,j-1) )/2/dl + ...
                nu*( ( vort(i+1,j)-2*vort(i,j)+vort(i-1,j) )/dl2 + ... 
                     ( vortnorthbc-2*vort(i,j)+vort(i,j-1) )/dl2 ); 
end

% West
i=1;
for j=2:Ny-2
    vortwestbc = ( 0 - stmfunc(i,j) - U_west(j)*dl)/(0.5*dl*dl);
    
    fac1 = -(stmfunc(i,j+1) - stmfunc(i,j-1))/2/dl;
    fac2 =  (stmfunc(i+1,j) - 0             )/2/dl;
 
    RHS(i,j) =  fac1*( vort(i+1,j)-vortwestbc  )/2/dl + ...
                fac2*( vort(i,j+1)-vort(i,j-1) )/2/dl + ...
                nu*( ( vort(i+1,j)-2*vort(i,j)+vortwestbc  )/dl2 + ... 
                     ( vort(i,j+1)-2*vort(i,j)+vort(i,j-1) )/dl2 ); 
end

% East
i=Nx-1;
for j=2:Ny-2
    vorteastbc = ( 0 - stmfunc(i,j) + U_east(j)*dl)/(0.5*dl*dl);
    
    fac1 = -(stmfunc(i,j+1) - stmfunc(i,j-1))/2/dl;
    fac2 =  (0              - stmfunc(i-1,j))/2/dl;
 
    RHS(i,j) =  fac1*( vorteastbc -vort(i-1,j) )/2/dl + ...
                fac2*( vort(i,j+1)-vort(i,j-1) )/2/dl + ...
                nu*( ( vorteastbc -2*vort(i,j)+vort(i-1,j) )/dl2 + ... 
                     ( vort(i,j+1)-2*vort(i,j)+vort(i,j-1) )/dl2 ); 
end

% South-west
i=1;j=1;

    vortsouthbc = ( 0 - stmfunc(i,j) + U_south(i)*dl)/(0.5*dl*dl);
    vortwestbc  = ( 0 - stmfunc(i,j) + U_west(j) *dl)/(0.5*dl*dl);
    
    fac1 = -(stmfunc(i,j+1) - 0 )/2/dl;
    fac2 =  (stmfunc(i+1,j) - 0 )/2/dl;

    RHS(i,j) =  fac1*( vort(i+1,j)-vortwestbc  )/2/dl + ...
                fac2*( vort(i,j+1)-vortsouthbc )/2/dl + ...
                nu*( ( vort(i+1,j)-2*vort(i,j)+vortwestbc  )/dl2 + ... 
                     ( vort(i,j+1)-2*vort(i,j)+vortsouthbc )/dl2 ); 
                    
% South-east          
i=Nx-1;j=1;

    vortsouthbc = ( 0 - stmfunc(i,j) + U_south(i)*dl)/(0.5*dl*dl);
    vorteastbc  = ( 0 - stmfunc(i,j) - U_east(j) *dl)/(0.5*dl*dl);
    
    fac1 = -(stmfunc(i,j+1) - 0)/2/dl;
    fac2 =  (0 - stmfunc(i-1,j))/2/dl;

    RHS(i,j) =  fac1*( vorteastbc -vort(i-1,j) )/2/dl + ...
                fac2*( vort(i,j+1)-vortsouthbc )/2/dl + ...
                nu*( ( vorteastbc -2*vort(i,j)+vort(i-1,j) )/dl2 + ... 
                     ( vort(i,j+1)-2*vort(i,j)+vortsouthbc )/dl2 ); 
                    
% North-east         
i=Nx-1;j=Ny-1;

    vortnorthbc = ( 0 - stmfunc(i,j) - U_north(i)*dl)/(0.5*dl*dl);
    vorteastbc  = ( 0 - stmfunc(i,j) - U_east(j) *dl)/(0.5*dl*dl);
        
    fac1 = -(0 - stmfunc(i,j-1))/2/dl;
    fac2 =  (0 - stmfunc(i-1,j))/2/dl;

    RHS(i,j) =  fac1*( vorteastbc -vort(i-1,j) )/2/dl + ...
                fac2*( vortnorthbc-vort(i,j-1) )/2/dl + ...
                nu*( ( vorteastbc -2*vort(i,j)+vort(i-1,j) )/dl2 + ... 
                     ( vortnorthbc-2*vort(i,j)+vort(i,j-1) )/dl2 );

% North-west          
i=1;j=Ny-1;

    vortnorthbc = ( 0 - stmfunc(i,j) - U_north(i)*dl)/(0.5*dl*dl);
    vortwestbc  = ( 0 - stmfunc(i,j) + U_west(j) *dl)/(0.5*dl*dl);
        
    fac1 = -(0 - stmfunc(i,j-1))/2/dl;
    fac2 =  (stmfunc(i+1,j) - 0)/2/dl;

    RHS(i,j) =  fac1*( vort(i+1,j)-vortwestbc  )/2/dl + ...
                fac2*( vortnorthbc-vort(i,j-1) )/2/dl + ...
                nu*( ( vort(i+1,j)-2*vort(i,j)+vortwestbc  )/dl2 + ... 
                     ( vortnorthbc-2*vort(i,j)+vort(i,j-1) )/dl2 ); 
                                                       
end

